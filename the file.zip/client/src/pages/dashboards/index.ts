export { default as AdminDashboard } from './AdminDashboard'
export { default as EditorDashboard } from './EditorDashboard'
export { default as RecruiterDashboard } from './RecruiterDashboard'
export { default as CandidateDashboard } from './CandidateDashboard'














