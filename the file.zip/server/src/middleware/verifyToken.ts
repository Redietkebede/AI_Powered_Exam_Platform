import admin from "../config/firebase";
import pool from "../config/db";
import { RequestHandler } from "express";

export const verifyToken: RequestHandler = async (req, res, next) => {
  try {
    const hdr = /^Bearer\s+(.+)$/i.exec(req.headers.authorization ?? "");
    if (!hdr) {
      return res
        .status(401)
        .json({ error: "Missing or invalid Authorization header" });
    }
    const idToken = hdr[1];

    // 1) Verify Firebase ID token
    const decoded = await admin.auth().verifyIdToken(idToken);

    // 2) Try to find a local user by firebase_uid
    let result = await pool.query(
      "SELECT id, role FROM users WHERE firebase_uid = $1 LIMIT 1",
      [decoded.uid]
    );
   

    // 3) If not found, provision only when email exists
    if (!result.rowCount) {
      if (!decoded.email) {
        return res
          .status(403)
          .json({ error: "Email required to provision user" });
      }
      const name = decoded.name ?? decoded.email.split("@")[0];
      // role default = candidate; tweak if you need admin/instructor bootstrap
      result = await pool.query(
        `INSERT INTO users (name, email, role, firebase_uid, created_at)
         VALUES ($1,$2,$3,$4,NOW())
         ON CONFLICT (firebase_uid) DO NOTHING
         RETURNING id, role`,
        [name, decoded.email, "candidate", decoded.uid]
      );

      // If a concurrent insert happened and RETURNING is empty, fetch again
      if (!result.rowCount) {
        result = await pool.query(
          "SELECT id, role FROM users WHERE firebase_uid = $1 LIMIT 1",
          [decoded.uid]
        );
      }

      if (result.rowCount === 0) {
        // extremely unlikely, but bail clearly
        return res.status(500).json({ error: "User provisioning failed" });
      }
    }

    // 4) Attach user to req (note: no 'uid' field unless you added it to your type)
    req.user = {
      uid: decoded.uid,
      id: result.rows[0].id,
      role: result.rows[0].role,
      firebaseUid: decoded.uid,
      email: decoded.email ?? null,
      token: decoded,
    };

    next();
  } catch (err) {
    console.error("[auth] verifyToken error:", err);
    return res.status(403).json({ error: "Unauthorized or token expired" });
  }
};
