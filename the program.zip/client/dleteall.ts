localStorage.removeItem("ai_exam_users");
