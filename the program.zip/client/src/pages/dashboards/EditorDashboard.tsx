import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { getQuestions } from "../../services/questionService";
import type { Question } from "../../types/question";

export default function EditorDashboard() {
  const [questions, setQuestions] = useState<Question[]>([]);

  useEffect(() => {
    let alive = true;
    getQuestions()
      .then((qs) => {
        if (alive) setQuestions(qs ?? []);
      })
      .catch(() => {
        if (alive) setQuestions([]);
      });
    return () => {
      alive = false;
    };
  }, []);

  const counts = useMemo(
    () => ({
      pending: questions.filter((q) => q.status === "pending").length,
      draft: questions.filter((q) => q.status === "draft").length,
      approved: questions.filter((q) => q.status === "approved").length,
      rejected: questions.filter((q) => q.status === "rejected").length,
    }),
    [questions]
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
        <div className="flex items-start justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full bg-[#0f2744]/5 px-3 py-1 text-xs font-medium text-[#0f2744]">
              Editor
            </div>
            <h1 className="mt-3 text-2xl font-semibold text-[#0f2744]">
              Dashboard
            </h1>
            <p className="mt-1 text-sm text-gray-600">
              Create, review, and approve exam content.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Link
              to="/app/ai-generator"
              className="rounded-md bg-[#ff7a59] px-4 py-2 text-sm font-medium text-white hover:brightness-110"
            >
              Create questions
            </Link>
            <Link
              to="/app/questions"
              className="rounded-md border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Question bank
            </Link>
          </div>
        </div>
      </div>

      {/* Content status */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          {
            label: "Pending",
            value: counts.pending,
            tone: "bg-amber-50 text-amber-700 border-amber-200",
          },
          {
            label: "Drafts",
            value: counts.draft,
            tone: "bg-gray-50 text-gray-700 border-gray-200",
          },
          {
            label: "Approved",
            value: counts.approved,
            tone: "bg-emerald-50 text-emerald-700 border-emerald-200",
          },
          {
            label: "Rejected",
            value: counts.rejected,
            tone: "bg-rose-50 text-rose-700 border-rose-200",
          },
        ].map((k) => (
          <div
            key={k.label}
            className={`rounded-lg border ${k.tone
              .split(" ")
              .at(-1)} bg-white p-5 shadow-sm`}
          >
            <div className={`h-1 w-full rounded ${k.tone.split(" ")[0]}`} />
            <div className="mt-3 text-xs text-gray-600">{k.label}</div>
            <div className="mt-1 text-2xl font-semibold text-[#0f2744]">
              {k.value}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
