// client/src/services/questionService.ts
import { api } from "../lib/api";
import type { QuestionCreateDTO, QuestionGenerateDTO } from "../types/api";
import type { Question } from "../types/question";
import type { DbQuestionRow } from "../adapters/dbQuestionRow";
import { mapDbRowToQuestion } from "../adapters/dbQuestionRow";

/* ------------------------ Legacy-friendly inputs ------------------------ */
type LegacyCreateInput = {
  stem: string;
  options: string[];
  correctIndex: number;
  difficulty: number | string;
  tags?: string[];
  subject?: string | null; // ignored by BE
};
type CreateInput = QuestionCreateDTO | LegacyCreateInput;

type LegacyGenerateInput = {
  topic: string;
  count: number;
  difficulty?: number | string;
  tags?: string[];
};
type GenerateInput = QuestionGenerateDTO | LegacyGenerateInput;

/* --------------------------- Optional list params --------------------------- */
/** If your BE supports filters/pagination, pass them; we only send valid values. */
export type ListParams = {
  status?: "pending" | "approved" | "rejected";
  limit?: number;
  offset?: number;
};

function buildQuery(params?: ListParams): string {
  const sp = new URLSearchParams();
  if (params) {
    if (params.status) sp.set("status", params.status);
    if (Number.isFinite(params.limit)) sp.set("limit", String(params.limit));
    if (Number.isFinite(params.offset)) sp.set("offset", String(params.offset));
  }
  const qs = sp.toString();
  return qs ? `?${qs}` : "";
}

/* --------------------------- Normalizers -> DTO -------------------------- */
const toDifficultyNum = (d: unknown): number | undefined => {
  if (typeof d === "number" && Number.isFinite(d)) return d;
  if (typeof d === "string") {
    const m: Record<string, number> = {
      "very easy": 1,
      easy: 2,
      medium: 3,
      hard: 4,
      "very hard": 5,
    };
    const v = m[d.trim().toLowerCase()];
    if (v) return v;
  }
  return undefined;
};

function toCreateDTO(input: CreateInput): QuestionCreateDTO {
  if ("question_text" in input) {
    const dto = input as QuestionCreateDTO;
    return {
      question_text: String(dto.question_text),
      options: (dto.options ?? []).map(String),
      correct_answer: Number(dto.correct_answer),
      difficulty: Number(dto.difficulty),
      tags: Array.isArray(dto.tags) ? dto.tags.map(String) : undefined,
    };
  }

  const legacy = input as LegacyCreateInput;
  const options = (legacy.options ?? [])
    .map((s) => String(s ?? "").trim())
    .filter(Boolean);

  let correct = Number(legacy.correctIndex);
  if (!Number.isFinite(correct) || correct < 0 || correct >= options.length) {
    correct = 0;
  }

  return {
    question_text: String(legacy.stem ?? "").trim(),
    options,
    correct_answer: correct,
    difficulty: toDifficultyNum(legacy.difficulty) ?? 3,
    tags: Array.isArray(legacy.tags) ? legacy.tags.map(String) : undefined,
  };
}

function toGenerateDTO(input: GenerateInput): QuestionGenerateDTO {
  if (
    "topic" in input &&
    "count" in input &&
    ("difficulty" in input
      ? typeof (input as any).difficulty === "number" ||
        (input as any).difficulty === undefined
      : true)
  ) {
    const dto = input as QuestionGenerateDTO;
    return {
      topic: String(dto.topic),
      count: Number(dto.count),
      difficulty:
        dto.difficulty === undefined ? undefined : Number(dto.difficulty),
      tags: Array.isArray(dto.tags) ? dto.tags.map(String) : undefined,
    };
  }

  const legacy = input as LegacyGenerateInput;
  return {
    topic: String(legacy.topic),
    count: Number(legacy.count),
    difficulty: toDifficultyNum(legacy.difficulty),
    tags: Array.isArray(legacy.tags) ? legacy.tags.map(String) : undefined,
  };
}

/* ------------------------------ Public API ------------------------------ */

/** List questions; pass params only if needed (we avoid sending blank/NaN). */
export async function getQuestions(params?: ListParams): Promise<Question[]> {
  const url = `/questions${buildQuery(params)}`;
  const data = await api.get<DbQuestionRow[] | { items: DbQuestionRow[] }>(url);
  const rows = Array.isArray(data) ? data : data?.items ?? [];
  return rows.map(mapDbRowToQuestion);
}

export async function createQuestion(input: CreateInput): Promise<Question> {
  const dto = toCreateDTO(input);
  const row = await api.post<DbQuestionRow>("/questions", dto);
  return mapDbRowToQuestion(row);
}

export function generateQuestions(input: GenerateInput) {
  const dto = toGenerateDTO(input);
  // BE returns a small report { inserted, topic, difficulty, generation_time, ... }
  return api.post("/questions/generate", dto);
}

/* ---- update status (approve/reject/pending/draft/archived) ---- */
export async function updateQuestionStatus(
  id: number,
  status: "pending" | "approved" | "rejected" | "draft" | "archived"
): Promise<Question> {
  const row = await api.patch<DbQuestionRow>(`/questions/${id}`, { status });
  return mapDbRowToQuestion(row);
}

/* ------------------------ remove a question ------------------------ */
export async function removeQuestion(id: number): Promise<void> {
  await api.del<void>(`/questions/${id}`);
}
