import { request } from "../lib/api";

export type Role = "admin" | "editor" | "recruiter" | "candidate";

export type User = {
  id: number;
  uid: string | null;        // firebase_uid in DB
  name: string | null;
  email: string;
  role: Role;
  createdAt: string;
  emailVerified?: boolean | null;
  lastLoginAt?: string | null;
  disabled?: boolean | null;
};

export type Me = {
  id: number;
  uid: string | null;
  name: string | null;
  email: string | null;
  role: Role;
};

const USERS_PATH = "/users";
const AUTH_ME_PATH = "/auth/me";

// ────────────────────────────────────────────────────────────
// Current user (uses /api/auth/me)
export async function getCurrentUser(): Promise<Me> {
  return request<Me>(AUTH_ME_PATH);
}

// List users from DB (admin only). Pass {enrich:true} to also pull Firebase metadata.
export async function getUsers(opts?: { enrich?: boolean }): Promise<User[]> {
  const q = opts?.enrich ? "?enrich=1" : "";
  const data = await request<{ items: User[] }>(`${USERS_PATH}${q}`);
  return data.items ?? [];
}

// Create a user (admin): creates Firebase account (email/name/password),
// then upserts the DB row with the chosen role and returns the record.
export type CreateUserInput = {
  email: string;
  name?: string;
  role: Role;
  password?: string; 
};

export async function createUser(input: CreateUserInput): Promise<User> {
  
  const body = {
    email: input.email.trim(),
    name: input.name?.trim() || undefined,
    role: input.role,
    password: input.password && input.password.length >= 6 ? input.password : undefined,
  };
  return request<User>(USERS_PATH, { method: "POST", body });
}

// Update a user's role (admin only)
export async function updateUserRole(id: number, role: Role): Promise<void> {
  await request(`${USERS_PATH}/${id}`, { method: "PATCH", body: { role } });
}

// Delete a user (admin only, optional)
export async function removeUser(id: number): Promise<void> {
  await request(`${USERS_PATH}/${id}`, { method: "DELETE" });
}

// Deprecated: the old mock login helper. Keep it to catch accidental use.
export function findUserByCredentials(): never {
  throw new Error(
    "Deprecated: use Firebase Auth on /login. findUserByCredentials() is not available."
  );
}

// ────────────────────────────────────────────────────────────
// Purge any leftover mock/localStorage data from the old demo auth.
const MOCK_PREFIXES = ["ai_exam_users", "ai_exam_user", "ai_exam_session", "ai_exam_auth"];

export function purgeMockUsers(): void {
  try {
    const ls = window.localStorage;
    for (const key of Object.keys(ls)) {
      if (MOCK_PREFIXES.some((p) => key.startsWith(p))) {
        ls.removeItem(key);
      }
    }
  } catch {
    /* ignore */
  }
}

// Expose a helper in dev so you can run it from the console easily.
if (import.meta.env.DEV) {
  (window as any).purgeMockUsers = purgeMockUsers;
}
