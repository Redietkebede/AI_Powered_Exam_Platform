import { Router } from "express";
import { verifyToken } from "../middleware/auth"; // your strict auth.ts
import { authorize, atLeast } from "../middleware/authorize";
import {
  createQuestions,
  listQuestions,
  deleteQuestion,
  publishQuestion,
} from "../controllers/questionControllers";

const router = Router();

// Only editor can generate questions
router.get(
  "/questions",
  verifyToken,
  authorize(["admin", "editor", "recruiter"]),
  listQuestions
);
router.post(
  "/questions",
  verifyToken,
  authorize(["editor", "admin"]),
  createQuestions
);
router.post(
  "/questions/generate",
  verifyToken,
  authorize(["editor"]),
  createQuestions
);
router.post(
  "/questions/:id/publish",
  verifyToken,
  atLeast("editor"),
  publishQuestion
);
router.delete(
  "/questions/:id",
  verifyToken,
  authorize(["admin", "editor"]),
  deleteQuestion
);

export default router;
